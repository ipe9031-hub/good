PPT AI Studio - Hosted Windows add-in
Server: https://good-red.vercel.app/
No Node.js or localhost certificate installation required.
Register manifest.xml in PowerPoint. See 설치안내.md.
Windows PowerPoint host validation: pending.
